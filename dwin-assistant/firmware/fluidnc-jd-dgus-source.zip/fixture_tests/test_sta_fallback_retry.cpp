#include "../FluidNC/src/WebUI/StaFallbackRetry.h"
#include <cassert>
#include <cstdint>
#include <iostream>

using Retry = WebUI::StaFallbackRetry;
using Action = Retry::Action;

static Action step(Retry& retry, uint32_t now, bool enabled = true, bool connected = false,
                   bool ap = true, bool clients = false, bool stopped = true) {
    return retry.poll(now, enabled, connected, ap, clients, stopped);
}

int main() {
    // Phone absent at boot: fallback AP stays available; retries are paced.
    Retry absent;
    assert(step(absent, 0) == Action::None);
    assert(step(absent, 14999) == Action::None);
    assert(step(absent, 15000) == Action::Begin);
    assert(absent.ownsStation());
    assert(step(absent, 15001) == Action::None);
    assert(step(absent, 44999) == Action::None);
    assert(step(absent, 45000) == Action::Begin);

    // A pending DHCP/association attempt is not restarted every poll.
    assert(step(absent, 45001) == Action::None);
    assert(step(absent, 74999) == Action::None);

    // Phone appears: stop retrying, preserve established station even in a job.
    assert(step(absent, 75000, true, true) == Action::None);
    assert(step(absent, 76000, true, true, true, false, false) == Action::None);
    assert(step(absent, 76001, true, true, true, true, false) == Action::None);
    assert(absent.ownsStation());

    // If association is pending when motion starts, cancel station only.
    Retry motion;
    step(motion, 0);
    assert(step(motion, 15000) == Action::Begin);
    assert(step(motion, 15001, true, false, true, false, false) == Action::Cancel);
    assert(!motion.ownsStation());
    assert(step(motion, 90000, true, false, true, false, false) == Action::None);
    assert(step(motion, 90001) == Action::None);
    assert(step(motion, 105000) == Action::Begin);

    // An attached fallback-AP client prevents starting or continuing a retry.
    Retry client;
    assert(step(client, 0, true, false, true, true) == Action::None);
    assert(step(client, 20000, true, false, true, true) == Action::None);
    assert(step(client, 21000) == Action::None);
    assert(step(client, 36000) == Action::Begin);
    assert(step(client, 36001, true, false, true, true) == Action::Cancel);
    assert(!client.ownsStation());

    // Explicit AP-only/off settings and missing SSID cannot launch attempts.
    Retry disabled;
    assert(step(disabled, 0, false) == Action::None);
    assert(step(disabled, 50000, false) == Action::None);
    assert(step(disabled, 50001) == Action::None);
    assert(step(disabled, 65001) == Action::Begin);
    assert(step(disabled, 65002, false) == Action::Cancel);

    // This feature never manages an ordinary STA-only connection.
    Retry stationOnly;
    assert(step(stationOnly, 0, true, false, false) == Action::None);
    assert(step(stationOnly, 50000, true, false, false) == Action::None);
    assert(!stationOnly.ownsStation());

    // Timer arithmetic remains valid when millis() wraps after about 49 days.
    Retry wrap;
    assert(step(wrap, UINT32_MAX - 10000) == Action::None);
    assert(step(wrap, 4998) == Action::None);
    assert(step(wrap, 4999) == Action::Begin);

    // A module restart forgets pending attempts and starts a fresh interval.
    wrap.reset();
    assert(!wrap.ownsStation());
    assert(step(wrap, 9000) == Action::None);
    assert(step(wrap, 24000) == Action::Begin);

    std::cout << "Fallback STA retry policy: absent/late phone, pending DHCP, established link, motion, AP client, disabled mode, STA-only, timer wrap and module restart passed\n";
}
