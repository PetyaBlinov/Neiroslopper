#include "../FluidNC/src/WebUI/ApListScanPolicy.h"
#include <cassert>
#include <iostream>

using Scan = WebUI::ApListScanPolicy;
using Action = Scan::Action;

int main() {
    // Ordinary AP-list scan borrows STA and releases only what it borrowed.
    Scan ap;
    assert(ap.start(true, true) == Action::BeginScan);
    assert(ap.start(false, false) == Action::None); // no second scan while running/results cached
    assert(ap.poll(false, false, false, true) == Action::None);
    assert(ap.poll(true, false, false, true) == Action::DisableStation);
    assert(ap.finish(false, false, true) == Action::None); // release is idempotent
    assert(ap.poll(true, false, false, true) == Action::None);

    // Finishing results never starts another scan. Only another explicit
    // request after deleting the old results may return BeginScan.
    Scan finish;
    assert(finish.start(true, true) == Action::BeginScan);
    assert(finish.finish(false, false, true) == Action::DisableStation);
    assert(finish.finish(false, false, true) == Action::None);
    assert(finish.start(true, true) == Action::BeginScan);

    // A station established while a scan runs always wins over cleanup.
    Scan connected;
    connected.start(true, true);
    assert(connected.poll(true, false, true, true) == Action::None);
    assert(connected.finish(false, true, true) == Action::None);
    assert(connected.poll(true, false, false, true) == Action::None);

    // A pending background phone retry keeps STA after the scan finishes.
    Scan retry;
    retry.start(true, true);
    assert(retry.finish(true, false, true) == Action::None);
    assert(retry.poll(true, false, false, true) == Action::None);

    // Scanning from STA-only or pre-existing AP_STA never owns that STA.
    Scan station;
    assert(station.start(true, false) == Action::BeginScan);
    assert(station.finish(false, false, true) == Action::None);
    station.start(true, true);
    station.reset();
    assert(station.finish(false, false, true) == Action::None);

    std::cout << "AP-list scan policy: explicit starts only, idempotent finish, connected STA, retry ownership, existing STA and reset passed\n";
}
