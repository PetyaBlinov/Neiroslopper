-> $X
<- ok
->   $X
<- ok
