// Copyright (c) 2021 -	Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

// The Channel class is for controlling FluidNC via a two-way communications
// channel, such as a USB serial link, a Bluetooth serial link, a Telnet-style
// TCP connection or a WebSocket stream.  Channel inherits from the Arduino
// File Stream (character input), which inherits from Print (character output).
//
// On top of those base classes, Channel adds the pollLine() method to collect
// a line of input - delimited by newline - while processing "realtime characters"
// that take effect immediately without regard to line boundaries.  It further
// adds the ack() method for flow control, to prevent GCode senders from
// overrunning input buffers.  The default implementation of ack() sends
// "ok" and "error:" messages via the standard Grbl serial protocol, but it
// could be implemented in other ways for different channel protocols.

#pragma once

#include "Error.h"        // Error
#include "GCode.h"        // gc_modal_t
#include "Types.h"        // MotorMask
#include "RealtimeCmd.h"  // Cmd
#include "UTF8.h"

#include "Pins/PinAttributes.h"
#include "Machine/EventPin.h"

#include <Stream.h>
#include <freertos/FreeRTOS.h>  // TickType_T
#include <freertos/semphr.h>
#include <atomic>
#include <queue>

class Channel : public Stream {
private:
    void pin_event(pinnum_t pinnum, bool active);

    static constexpr int PinACK = 0xB2;
    static constexpr int PinNAK = 0xB3;
    static constexpr int PinRST = 0xB4;

    static constexpr int timeout = 2000;

public:
    // PinLowFirst/PinHighFirst are inclusive lower bounds and PinLowLast/PinHighLast
    // are exclusive upper bounds (see the "cmd < PinLowLast" style checks in
    // handleRealtimeCharacter()), so each range should span a full 0x40 codepoints,
    // for pin indices 0-63. Making *Last one codepoint short of the next range's
    // *First, as previously written, wasted one codepoint per range (0x13f and 0x17f
    // decoded to neither a Low nor a High pin event) and capped the usable pin index
    // at 62 instead of 63.
    static constexpr int PinLowFirst  = 0x100;
    static constexpr int PinLowLast   = 0x140;
    static constexpr int PinHighFirst = 0x140;
    static constexpr int PinHighLast  = 0x180;
    // Highest usable pin-event index, e.g. for a well-known software pin that every
    // channel should recognize regardless of per-instance/per-config pin assignment.
    static constexpr int MaxPinIndex = PinLowLast - PinLowFirst - 1;

    static constexpr int maxLine = 255;

    uint32_t _message_level = MsgLevelVerbose;

protected:
    std::string _name;
    char        _line[maxLine] = {};
    size_t      _linelen       = 0;
    bool        _addCR         = false;
    char        _lastWasCR     = false;

    mutable SemaphoreHandle_t _queue_mutex = xSemaphoreCreateMutex();
    std::queue<uint8_t>       _queue;

    // _queue holds non-realtime input bytes seen by pollLine(nullptr) until a
    // pollLine(line) call consumes them.  A channel that is polled for realtime
    // characters but never for lines - e.g. any non-job channel while a job is
    // running - would otherwise grow _queue without bound.  Bound it at a few
    // lines of slack (~4).  When a new line arrives with the queue already at
    // the bound, that whole line is discarded through its newline; a line
    // already in progress is allowed to finish, so the queue never holds a
    // partial line.  State below is touched only under _queue_mutex.
    static constexpr size_t _queue_limit        = 4 * maxLine;
    bool                    _queue_at_line_start = true;   // last queued byte ended a line (or queue empty)
    bool                    _queue_discarding    = false;  // dropping the rest of an over-limit line
    bool                    _queue_overflow_logged = false;  // one debug line per overflow episode
    // Enqueue one non-realtime input byte, applying the whole-line drop policy.
    void queue_push(uint8_t byte);

    // Send interval reports while idle too, not only while in motion.
    bool _report_when_idle = false;

    uint32_t _reportInterval = 0;
    int32_t  _nextReportTime = 0;

    gc_modal_t  _lastModal        = modal_defaults;
    uint8_t     _lastTool         = 0;
    float       _lastSpindleSpeed = 0;
    float       _lastFeedRate     = 0;
    MotorMask   _lastLimits       = 0;
    bool        _lastJobActive    = false;
    std::string _lastPinString    = "";

    bool       _reportState = true;
    bool       _reportOvr   = true;
    bool       _reportWco   = true;
    CoordIndex _reportNgc   = CoordIndex::End;

    Cmd _last_rt_cmd = Cmd::None;

    std::map<int, InputPin*> _pins;

    // Pin events not tied to any one Channel instance -- shared across all channels,
    // so a pin registered here is recognized on every current and future channel
    // (WebSocket, Telnet, UART, ...), unlike _pins above which is per-instance and
    // only reachable on whichever channel a real/configured Pin happens to be bound to.
    static std::map<int, InputPin*> _virtual_pins;

    UTF8 _utf8;

    bool _ended   = false;
    bool _percent = false;

protected:
    bool _active = true;
    bool _paused = false;

    // Set by pollLine() when it returns a complete line, cleared by ack() (or
    // by clear_pending_ack(), for a caller that must not write to the
    // channel but still needs to unblock it -- see its declaration). While
    // set, pollLine() behaves as though called with line == nullptr: realtime
    // characters still work, but no further line is completed, and
    // non-realtime bytes queue in _queue instead (see its comment) until the
    // ack arrives, however long that takes -- including the duration of an
    // M6/$SD/Run job this same line started (FluidNC issue #1862). This
    // caps a sender at one line in flight without rejecting anything it
    // sends ahead of that ack under character-counting flow control: it
    // simply waits in _queue and is processed, in order, once unblocked.
    //
    // pollLine() sets it on the polling task, but ack()/clear_pending_ack()
    // can run on either task (protocol_main_loop's cmd_queue consumer calls
    // ack() directly on the protocol task; a deferred job's completion,
    // Job::unnest()/Job::abort(), calls it from the polling task; flushRx()
    // can run from whichever task resets the system) -- atomic like
    // _processing_refs/_closing below, not a plain bool, so a write on one
    // task is guaranteed visible to a read on the other.
    std::atomic<bool> _pending_ack { false };

    std::atomic<uint32_t> _queued_log_refs { 0 };
    std::atomic<uint32_t> _processing_refs { 0 };
    std::atomic<bool>     _closing { false };

public:
    explicit Channel(const std::string& name, bool addCR = false);
    explicit Channel(const char* name, bool addCR = false);
    Channel(const char* name, objnum_t num, bool addCR = false);

    Channel(const Channel&)            = delete;
    Channel& operator=(const Channel&) = delete;
    Channel(Channel&&)                 = delete;
    Channel& operator=(Channel&&)      = delete;

    virtual ~Channel() {
        if (_queue_mutex) {
            vSemaphoreDelete(_queue_mutex);
            _queue_mutex = nullptr;
        }
    }

    int8_t _ackwait = 0;  // 1 - waiting, 0 - ACKed, -1 - NAKed

    virtual void  init() {}
    virtual void  handle() {}
    virtual Error pollLine(char* line);
    virtual void  ack(Error status);
    // Clears the pending-ack gate pollLine() set for the line just resolved,
    // without writing anything to the channel -- for a caller that has a
    // reason not to call ack() (e.g. protocol_main_loop skips it on
    // sys.abort(), where a channel could be mid-teardown) but must still
    // unblock the channel's next line, or it would stay gated forever.
    void        clear_pending_ack() { _pending_ack.store(false, std::memory_order_release); }
    const char* name() { return _name.c_str(); }
#ifdef JD_DGUS_NATIVE
    uint32_t panelPeer = 0;  // Network byte order, assigned only to Telnet channels.
#endif

    virtual void sendLine(MsgLevel level, const char* line);
    virtual void sendLine(MsgLevel level, const std::string* line);
    virtual void sendLine(MsgLevel level, const std::string& line);

    size_t _line_number = 0;

    std::string _progress;

    // rx_buffer_available() is the number of bytes that can be sent without overflowing
    // a reception buffer, even if the system is busy.  Channels that can handle external
    // input via an interrupt or other background mechanism should override it to return
    // the remaining space that mechanism has available.
    // The queue can handle more than 256 characters but we don't want it to get too
    // large, so we report a limited size.
    virtual int rx_buffer_available() { return std::max(0, 256 - int(queued_bytes())); }

    // flushRx() discards any characters that have already been received.  It is used
    // after a reset, so that anything already sent will not be processed.
    virtual void flushRx();

    // realtimeOkay() returns true if the channel can currently interpret the character as
    // a Grbl realtime character.  Some situations where it might return false are when
    // the channel is being used for file upload or if the channel is doing line editing
    // and is in the middle of an escape sequence that could include what would otherwise
    // be a realtime character.
    virtual bool realtimeOkay(char c) { return true; }

    void handleRealtimeCharacter(uint8_t byte);

    // lineComplete() accumulates the character into the line, returning true if a line
    // end is seen.
    virtual bool lineComplete(char* line, char c);

    virtual size_t timedReadBytes(char* buffer, size_t length, TickType_t timeout) {
        setTimeout(timeout);
        return readBytes(buffer, length);
    }

    virtual bool is_visible(const std::string& stem, std::string extension, bool isdir);

    size_t timedReadBytes(uint8_t* buffer, size_t length, TickType_t timeout) {
        return timedReadBytes(reinterpret_cast<char*>(buffer), length, timeout);
    }

    void writeUTF8(uint32_t code);

    bool setCr(bool on) {
        bool retval = _addCR;
        _addCR      = on;
        return retval;
    }

    void notifyState() { _reportState = true; }
    void notifyOvr() { _reportOvr = true; }
    void notifyWco() { _reportWco = true; }
    void notifyNgc(CoordIndex coord) { _reportNgc = coord; }

    int peek() override { return -1; }
    int read() override { return -1; }
    int available() override { return queued_bytes(); }

    virtual void print_msg(MsgLevel level, const char* msg);

    void print_msg(MsgLevel level, const std::string& msg) { print_msg(level, msg.c_str()); }

    uint32_t     setReportInterval(uint32_t ms);
    uint32_t     getReportInterval() { return _reportInterval; }
    virtual void autoReport();
    void         autoReportGCodeState();

    void push(uint8_t byte);
    void push(const uint8_t* data, size_t length) {
        while (length--) {
            push(*data++);
        }
    }
    void push(std::string_view data) {
        for (auto const& c : data) {
            push((uint8_t)c);
        }
    }
    void push(const std::string& s) { push(reinterpret_cast<const uint8_t*>(s.c_str()), s.length()); }

    size_t queued_bytes() const;
    bool   try_pop_queued_byte(uint8_t& byte);

    void end() { _ended = true; }
    void percent() { _percent = true; }

    // Pin extender functions
    virtual void out(const char* s, const char* tag);
    virtual void out(const std::string& s, const char* tag);
    virtual void out_acked(const std::string& s, const char* tag);

    virtual void beginJSON(const char* json_tag) {}
    virtual void endJSON(const char* json_tag) {}

    void ready();
    void registerEvent(pinnum_t pinnum, InputPin* obj);

    // Registers obj at pinnum in the shared, channel-independent virtual-pin table
    // (see _virtual_pins). Intended to be called once, during single-threaded init,
    // before any channel starts polling.
    static void registerVirtualPin(pinnum_t pinnum, InputPin* obj);

    size_t lineNumber() { return _line_number; }
    void   setLineNumber(size_t line_number) { _line_number = line_number; }

    virtual void   save() {}
    virtual void   restore() {}
    virtual size_t position() { return 0; }
    virtual void   set_position(size_t pos) {}

    void pause();
    void resume();

    bool     try_acquire_log_ref();
    void     release_log_ref();
    bool     try_acquire_processing_ref();
    void     release_processing_ref();
    void     begin_closing();
    bool     is_closing() const;
    uint32_t pending_log_refs() const;
    uint32_t pending_processing_refs() const;
};
