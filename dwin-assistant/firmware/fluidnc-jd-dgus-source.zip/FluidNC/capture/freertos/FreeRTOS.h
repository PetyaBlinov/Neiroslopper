#pragma once

#include "task.h"
#include "queue.h"
#include "FreeRTOSTypes.h"
#include <mutex>
#include <atomic>

/* "mux" data structure (spinlock) */

struct portMUX_TYPE {
    std::atomic<bool> lock_ = { false };

    void lock() {
        while (lock_.exchange(true, std::memory_order_acquire))
            ;
    }

    void unlock() { lock_.store(false, std::memory_order_release); }
};

inline void vTaskExitCritical(portMUX_TYPE* mux) {
    mux->lock();
}
inline void vTaskEnterCritical(portMUX_TYPE* mux) {
    mux->unlock();
}

inline void vTaskPrioritySet(TaskHandle_t xTask, UBaseType_t uxNewPriority) {}

inline void vTaskPrioritySet(portMUX_TYPE* mux) {
    mux->unlock();
}

#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))

inline size_t xPortGetFreeHeapSize() {
    return 500000;
}

#define INC_FREERTOS_H
#define PRIVILEGED_FUNCTION
#define configMINIMAL_STACK_SIZE 768
